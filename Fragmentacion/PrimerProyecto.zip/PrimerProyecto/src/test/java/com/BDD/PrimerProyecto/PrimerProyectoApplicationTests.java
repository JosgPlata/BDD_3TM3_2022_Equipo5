package com.BDD.PrimerProyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimerProyectoApplicationTests {



	@Test
	void contextLoads() {
	}

}
