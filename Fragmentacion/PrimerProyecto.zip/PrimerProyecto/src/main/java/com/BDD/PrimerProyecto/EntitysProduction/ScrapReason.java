package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import java.time.Instant;

@Entity
public class ScrapReason {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ScrapReasonID", nullable = false)
    private Integer id;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

/*
  TODO [JPA Buddy] create field to map the 'Name' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "Name", columnDefinition = "Name not null")
  private Object name;
*/
}