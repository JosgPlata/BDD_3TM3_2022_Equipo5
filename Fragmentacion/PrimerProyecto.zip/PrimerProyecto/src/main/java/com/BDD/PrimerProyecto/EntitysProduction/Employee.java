package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

@Entity
public class Employee {
    @Id
    @Column(name = "BusinessEntityID", nullable = false)
    private Integer id;

    @Column(name = "NationalIDNumber", nullable = false, length = 15)
    private String nationalIDNumber;

    @Column(name = "LoginID", nullable = false, length = 256)
    private String loginID;

    @Column(name = "OrganizationLevel")
    private Integer organizationLevel;

    @Column(name = "JobTitle", nullable = false, length = 50)
    private String jobTitle;

    @Column(name = "BirthDate", nullable = false)
    private LocalDate birthDate;

    @Column(name = "MaritalStatus", nullable = false, length = 1)
    private String maritalStatus;

    @Column(name = "Gender", nullable = false, length = 1)
    private String gender;

    @Column(name = "HireDate", nullable = false)
    private LocalDate hireDate;

    @Column(name = "VacationHours", nullable = false)
    private Integer vacationHours;
    @Column(name = "rowguid", nullable = false)
    private UUID rowguid;

    @Column(name = "SickLeaveHours", nullable = false)
    private Integer sickLeaveHours;
    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNationalIDNumber() {
        return nationalIDNumber;
    }

    public void setNationalIDNumber(String nationalIDNumber) {
        this.nationalIDNumber = nationalIDNumber;
    }

    public String getLoginID() {
        return loginID;
    }

    public void setLoginID(String loginID) {
        this.loginID = loginID;
    }

    public Integer getOrganizationLevel() {
        return organizationLevel;
    }

    public void setOrganizationLevel(Integer organizationLevel) {
        this.organizationLevel = organizationLevel;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public Integer getVacationHours() {
        return vacationHours;
    }

    public void setVacationHours(Integer vacationHours) {
        this.vacationHours = vacationHours;
    }

    public Integer getSickLeaveHours() {
        return sickLeaveHours;
    }

    public void setSickLeaveHours(Integer sickLeaveHours) {
        this.sickLeaveHours = sickLeaveHours;
    }

    public UUID getRowguid() {
        return rowguid;
    }

    public void setRowguid(UUID rowguid) {
        this.rowguid = rowguid;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

/*
  TODO [JPA Buddy] create field to map the 'OrganizationNode' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "OrganizationNode", columnDefinition = "hierarchyid(892)")
  private Object organizationNode;
*/
/*
  TODO [JPA Buddy] create field to map the 'SalariedFlag' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "SalariedFlag", columnDefinition = "Flag(1) not null")
  private Object salariedFlag;
*/
/*
  TODO [JPA Buddy] create field to map the 'CurrentFlag' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "CurrentFlag", columnDefinition = "Flag(1) not null")
  private Object currentFlag;
*/
}