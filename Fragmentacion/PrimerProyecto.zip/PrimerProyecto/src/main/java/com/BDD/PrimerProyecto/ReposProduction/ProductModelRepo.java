package com.BDD.PrimerProyecto.ReposProduction;

import com.BDD.PrimerProyecto.EntitysProduction.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductModelRepo extends CrudRepository<Product,Integer> {
}
