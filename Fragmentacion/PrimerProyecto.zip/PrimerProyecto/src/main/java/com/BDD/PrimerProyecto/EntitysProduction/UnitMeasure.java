package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.time.Instant;

@Entity
public class UnitMeasure {
    @Id
    @Column(name = "UnitMeasureCode", nullable = false, length = 3)
    private String id;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

/*
  TODO [JPA Buddy] create field to map the 'Name' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "Name", columnDefinition = "Name not null")
  private Object name;
*/
}