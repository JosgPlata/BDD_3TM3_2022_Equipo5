package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
public class ProductInventory {
    @EmbeddedId
    private ProductInventoryId id;

    @MapsId("productID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ProductID", nullable = false)
    private Product productID;

    @MapsId("locationID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "LocationID", nullable = false)
    private Location locationID;

    @Column(name = "Shelf", nullable = false, length = 10)
    private String shelf;

    @Column(name = "Bin", nullable = false)
    private Integer bin;

    @Column(name = "Quantity", nullable = false)
    private Integer quantity;

    @Column(name = "rowguid", nullable = false)
    private UUID rowguid;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public ProductInventoryId getId() {
        return id;
    }

    public void setId(ProductInventoryId id) {
        this.id = id;
    }

    public Product getProductID() {
        return productID;
    }

    public void setProductID(Product productID) {
        this.productID = productID;
    }

    public Location getLocationID() {
        return locationID;
    }

    public void setLocationID(Location locationID) {
        this.locationID = locationID;
    }

    public String getShelf() {
        return shelf;
    }

    public void setShelf(String shelf) {
        this.shelf = shelf;
    }

    public Integer getBin() {
        return bin;
    }

    public void setBin(Integer bin) {
        this.bin = bin;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public UUID getRowguid() {
        return rowguid;
    }

    public void setRowguid(UUID rowguid) {
        this.rowguid = rowguid;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

}