package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import java.time.Instant;

@Entity
public class ProductModelProductDescriptionCulture {
    @EmbeddedId
    private ProductModelProductDescriptionCultureId id;

    @MapsId("productModelID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ProductModelID", nullable = false)
    private ProductModel productModelID;

    @MapsId("productDescriptionID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ProductDescriptionID", nullable = false)
    private ProductDescription productDescriptionID;

    @MapsId("cultureID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "CultureID", nullable = false)
    private Culture cultureID;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public ProductModelProductDescriptionCultureId getId() {
        return id;
    }

    public void setId(ProductModelProductDescriptionCultureId id) {
        this.id = id;
    }

    public ProductModel getProductModelID() {
        return productModelID;
    }

    public void setProductModelID(ProductModel productModelID) {
        this.productModelID = productModelID;
    }

    public ProductDescription getProductDescriptionID() {
        return productDescriptionID;
    }

    public void setProductDescriptionID(ProductDescription productDescriptionID) {
        this.productDescriptionID = productDescriptionID;
    }

    public Culture getCultureID() {
        return cultureID;
    }

    public void setCultureID(Culture cultureID) {
        this.cultureID = cultureID;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

}