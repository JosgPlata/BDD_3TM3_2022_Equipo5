package com.BDD.PrimerProyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;


@SpringBootApplication
public class PrimerProyectoApplication {
	/*@Bean
	@Primary
	@ConfigurationProperties(prefix = "spring.datasource.")
	public DataSource ds1() {
		return DataSourceBuilder.create().build();
	}
	@Bean
	@ConfigurationProperties(prefix = "spring1.datasource.")
	public DataSource ds() {
		return DataSourceBuilder.create().build();
	}*/
	public static void main(String[] args) {

		SpringApplication.run(PrimerProyectoApplication.class, args);


	}

}

