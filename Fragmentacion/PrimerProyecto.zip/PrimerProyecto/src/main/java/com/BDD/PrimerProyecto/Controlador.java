package com.BDD.PrimerProyecto;
import com.BDD.PrimerProyecto.EntitysProduction.Product;
import com.BDD.PrimerProyecto.ReposProduction.ProductModelRepo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.web.bind.annotation.*;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
public class Controlador {

@Autowired
List<DataSource> ds;
    @GetMapping("/")
    public String index() throws JsonProcessingException, SQLException {

        return "PRACTICA FRAGMENTACIÓN";
    }
    @GetMapping("/1")
    public String Q1(@RequestParam String region) throws JsonProcessingException {
        Integer opt=1;
        switch (region){
            case "Europe":
                opt=3;
                System.out.println("eruo");
                break;
            case "Pacific":
                opt=2;
                System.out.println("pac\n\n");
                break;
            case "North America":
                opt=1;
                System.out.println("NA\n\n");
                break;
            default:
                opt=1;
                System.out.println("DEF\n\n");
        }
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q1");

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        inParamMap.put("Reg", opt);
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/2")
    public String Q2(@RequestParam Integer Opcion) throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q2_"+Opcion.toString());

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/3")
    public String Q3() throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q3");

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/4")
    public String Q4() throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q4");

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/5")
    public String Q5(@RequestParam Integer Opcion) throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q5_"+Opcion.toString());

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/6")
    public String Q6() throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q6");

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/7")
    public String Q7(@RequestParam Integer Nsc) throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q7");

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        inParamMap.put("Nsub",Nsc );
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/8")
    public String Q8() throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q8");

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/9")
    public String Q9() throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q9");

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @GetMapping("/10")
    public String Q10() throws JsonProcessingException {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(ds.get(0))
                .withProcedureName("Q10");

        Map<String, Object> inParamMap = new HashMap<String, Object>();
        SqlParameterSource in = new MapSqlParameterSource(inParamMap);


        Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(simpleJdbcCallResult);
        return json;
    }
    @Autowired
    ProductModelRepo productModelRepo;

    @GetMapping("/AllProduct")
    public ArrayList<Product> obtenerProductos(){
        return (ArrayList<Product>) productModelRepo.findAll();
    }


}
