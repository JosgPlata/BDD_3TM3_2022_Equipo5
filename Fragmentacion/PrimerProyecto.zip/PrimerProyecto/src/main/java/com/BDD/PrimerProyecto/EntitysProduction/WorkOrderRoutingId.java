package com.BDD.PrimerProyecto.EntitysProduction;

import org.hibernate.Hibernate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class WorkOrderRoutingId implements Serializable {
    private static final long serialVersionUID = -7105149067004140956L;
    @Column(name = "WorkOrderID", nullable = false)
    private Integer workOrderID;

    @Column(name = "ProductID", nullable = false)
    private Integer productID;

    @Column(name = "OperationSequence", nullable = false)
    private Integer operationSequence;

    public Integer getWorkOrderID() {
        return workOrderID;
    }

    public void setWorkOrderID(Integer workOrderID) {
        this.workOrderID = workOrderID;
    }

    public Integer getProductID() {
        return productID;
    }

    public void setProductID(Integer productID) {
        this.productID = productID;
    }

    public Integer getOperationSequence() {
        return operationSequence;
    }

    public void setOperationSequence(Integer operationSequence) {
        this.operationSequence = operationSequence;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        WorkOrderRoutingId entity = (WorkOrderRoutingId) o;
        return Objects.equals(this.operationSequence, entity.operationSequence) &&
                Objects.equals(this.productID, entity.productID) &&
                Objects.equals(this.workOrderID, entity.workOrderID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(operationSequence, productID, workOrderID);
    }

}