package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import javax.xml.validation.Schema;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(schema = "PRODUCTION")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ProductID", nullable = false)
    private Integer id;

    @Column(name = "ProductNumber", nullable = false, length = 25)
    private String productNumber;

    @Column(name = "Color", length = 15)
    private String color;

    @Column(name = "SafetyStockLevel", nullable = false)
    private Integer safetyStockLevel;

    @Column(name = "ReorderPoint", nullable = false)
    private Integer reorderPoint;

    @Column(name = "StandardCost", nullable = false, precision = 19, scale = 4)
    private BigDecimal standardCost;

    @Column(name = "ListPrice", nullable = false, precision = 19, scale = 4)
    private BigDecimal listPrice;

    @Column(name = "\"Size\"", length = 5)
    private String size;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SizeUnitMeasureCode")
    private UnitMeasure sizeUnitMeasureCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "WeightUnitMeasureCode")
    private UnitMeasure weightUnitMeasureCode;

    @Column(name = "Weight", precision = 8, scale = 2)
    private BigDecimal weight;

    @Column(name = "DaysToManufacture", nullable = false)
    private Integer daysToManufacture;

    @Column(name = "ProductLine", length = 2)
    private String productLine;

    @Column(name = "Class", length = 2)
    private String _class;

    @Column(name = "Style", length = 2)
    private String style;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ProductSubcategoryID")
    private ProductSubcategory productSubcategoryID;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ProductModelID")
    private ProductModel productModelID;
    @Column(name = "DiscontinuedDate")
    private Instant discontinuedDate;

    @Column(name = "SellStartDate", nullable = false)
    private Instant sellStartDate;
    @Column(name = "rowguid", nullable = false)
    private UUID rowguid;

    @Column(name = "SellEndDate")
    private Instant sellEndDate;
    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getSafetyStockLevel() {
        return safetyStockLevel;
    }

    public void setSafetyStockLevel(Integer safetyStockLevel) {
        this.safetyStockLevel = safetyStockLevel;
    }

    public Integer getReorderPoint() {
        return reorderPoint;
    }

    public void setReorderPoint(Integer reorderPoint) {
        this.reorderPoint = reorderPoint;
    }

    public BigDecimal getStandardCost() {
        return standardCost;
    }

    public void setStandardCost(BigDecimal standardCost) {
        this.standardCost = standardCost;
    }

    public BigDecimal getListPrice() {
        return listPrice;
    }

    public void setListPrice(BigDecimal listPrice) {
        this.listPrice = listPrice;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public UnitMeasure getSizeUnitMeasureCode() {
        return sizeUnitMeasureCode;
    }

    public void setSizeUnitMeasureCode(UnitMeasure sizeUnitMeasureCode) {
        this.sizeUnitMeasureCode = sizeUnitMeasureCode;
    }

    public UnitMeasure getWeightUnitMeasureCode() {
        return weightUnitMeasureCode;
    }

    public void setWeightUnitMeasureCode(UnitMeasure weightUnitMeasureCode) {
        this.weightUnitMeasureCode = weightUnitMeasureCode;
    }

    public BigDecimal getWeight() {
        return weight;
    }

    public void setWeight(BigDecimal weight) {
        this.weight = weight;
    }

    public Integer getDaysToManufacture() {
        return daysToManufacture;
    }

    public void setDaysToManufacture(Integer daysToManufacture) {
        this.daysToManufacture = daysToManufacture;
    }

    public String getProductLine() {
        return productLine;
    }

    public void setProductLine(String productLine) {
        this.productLine = productLine;
    }

    public String get_class() {
        return _class;
    }

    public void set_class(String _class) {
        this._class = _class;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public ProductSubcategory getProductSubcategoryID() {
        return productSubcategoryID;
    }

    public void setProductSubcategoryID(ProductSubcategory productSubcategoryID) {
        this.productSubcategoryID = productSubcategoryID;
    }

    public ProductModel getProductModelID() {
        return productModelID;
    }

    public void setProductModelID(ProductModel productModelID) {
        this.productModelID = productModelID;
    }

    public Instant getSellStartDate() {
        return sellStartDate;
    }

    public void setSellStartDate(Instant sellStartDate) {
        this.sellStartDate = sellStartDate;
    }

    public Instant getSellEndDate() {
        return sellEndDate;
    }

    public void setSellEndDate(Instant sellEndDate) {
        this.sellEndDate = sellEndDate;
    }

    public Instant getDiscontinuedDate() {
        return discontinuedDate;
    }

    public void setDiscontinuedDate(Instant discontinuedDate) {
        this.discontinuedDate = discontinuedDate;
    }

    public UUID getRowguid() {
        return rowguid;
    }

    public void setRowguid(UUID rowguid) {
        this.rowguid = rowguid;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

/*
  TODO [JPA Buddy] create field to map the 'Name' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "Name", columnDefinition = "Name not null")
  private Object name;
*/
/*
  TODO [JPA Buddy] create field to map the 'MakeFlag' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "MakeFlag", columnDefinition = "Flag(1) not null")
  private Object makeFlag;
*/
/*
  TODO [JPA Buddy] create field to map the 'FinishedGoodsFlag' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "FinishedGoodsFlag", columnDefinition = "Flag(1) not null")
  private Object finishedGoodsFlag;
*/
}