package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import java.time.Instant;

@Entity
public class ProductModelIllustration {
    @EmbeddedId
    private ProductModelIllustrationId id;

    @MapsId("productModelID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ProductModelID", nullable = false)
    private ProductModel productModelID;

    @MapsId("illustrationID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "IllustrationID", nullable = false)
    private Illustration illustrationID;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public ProductModelIllustrationId getId() {
        return id;
    }

    public void setId(ProductModelIllustrationId id) {
        this.id = id;
    }

    public ProductModel getProductModelID() {
        return productModelID;
    }

    public void setProductModelID(ProductModel productModelID) {
        this.productModelID = productModelID;
    }

    public Illustration getIllustrationID() {
        return illustrationID;
    }

    public void setIllustrationID(Illustration illustrationID) {
        this.illustrationID = illustrationID;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

}