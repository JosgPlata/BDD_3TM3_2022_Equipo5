package com.BDD.PrimerProyecto.ReposProduction;

import com.BDD.PrimerProyecto.EntitysSales.Customer;
import org.springframework.data.repository.CrudRepository;

/*public interface CustomerModelRepo extends CrudRepository<Customer,Integer> {
}
*/