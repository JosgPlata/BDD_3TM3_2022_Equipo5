package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
public class ProductCostHistory {
    @EmbeddedId
    private ProductCostHistoryId id;

    @MapsId("productID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ProductID", nullable = false)
    private Product productID;

    @Column(name = "EndDate")
    private Instant endDate;

    @Column(name = "StandardCost", nullable = false, precision = 19, scale = 4)
    private BigDecimal standardCost;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public ProductCostHistoryId getId() {
        return id;
    }

    public void setId(ProductCostHistoryId id) {
        this.id = id;
    }

    public Product getProductID() {
        return productID;
    }

    public void setProductID(Product productID) {
        this.productID = productID;
    }

    public Instant getEndDate() {
        return endDate;
    }

    public void setEndDate(Instant endDate) {
        this.endDate = endDate;
    }

    public BigDecimal getStandardCost() {
        return standardCost;
    }

    public void setStandardCost(BigDecimal standardCost) {
        this.standardCost = standardCost;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

}