package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "BillOfMaterials",schema = "Production")
public class BillOfMaterial {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BillOfMaterialsID", nullable = false)
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ProductAssemblyID")
    private Product productAssemblyID;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ComponentID", nullable = false)
    private Product componentID;

    @Column(name = "StartDate", nullable = false)
    private Instant startDate;

    @Column(name = "EndDate")
    private Instant endDate;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "UnitMeasureCode", nullable = false)
    private UnitMeasure unitMeasureCode;

    @Column(name = "BOMLevel", nullable = false)
    private Integer bOMLevel;

    @Column(name = "PerAssemblyQty", nullable = false, precision = 8, scale = 2)
    private BigDecimal perAssemblyQty;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Product getProductAssemblyID() {
        return productAssemblyID;
    }

    public void setProductAssemblyID(Product productAssemblyID) {
        this.productAssemblyID = productAssemblyID;
    }

    public Product getComponentID() {
        return componentID;
    }

    public void setComponentID(Product componentID) {
        this.componentID = componentID;
    }

    public Instant getStartDate() {
        return startDate;
    }

    public void setStartDate(Instant startDate) {
        this.startDate = startDate;
    }

    public Instant getEndDate() {
        return endDate;
    }

    public void setEndDate(Instant endDate) {
        this.endDate = endDate;
    }

    public UnitMeasure getUnitMeasureCode() {
        return unitMeasureCode;
    }

    public void setUnitMeasureCode(UnitMeasure unitMeasureCode) {
        this.unitMeasureCode = unitMeasureCode;
    }

    public Integer getBOMLevel() {
        return bOMLevel;
    }

    public void setBOMLevel(Integer bOMLevel) {
        this.bOMLevel = bOMLevel;
    }

    public BigDecimal getPerAssemblyQty() {
        return perAssemblyQty;
    }

    public void setPerAssemblyQty(BigDecimal perAssemblyQty) {
        this.perAssemblyQty = perAssemblyQty;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

}