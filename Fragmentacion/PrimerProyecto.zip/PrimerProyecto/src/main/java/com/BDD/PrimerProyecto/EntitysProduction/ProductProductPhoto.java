package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import java.time.Instant;

@Entity
public class ProductProductPhoto {
    @EmbeddedId
    private ProductProductPhotoId id;

    @MapsId("productID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ProductID", nullable = false)
    private Product productID;

    @MapsId("productPhotoID")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ProductPhotoID", nullable = false)
    private ProductPhoto productPhotoID;

    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public ProductProductPhotoId getId() {
        return id;
    }

    public void setId(ProductProductPhotoId id) {
        this.id = id;
    }

    public Product getProductID() {
        return productID;
    }

    public void setProductID(Product productID) {
        this.productID = productID;
    }

    public ProductPhoto getProductPhotoID() {
        return productPhotoID;
    }

    public void setProductPhotoID(ProductPhoto productPhotoID) {
        this.productPhotoID = productPhotoID;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

/*
  TODO [JPA Buddy] create field to map the '\"Primary\"' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "\"Primary\"", columnDefinition = "Flag(1) not null")
  private Object primary;
*/
}