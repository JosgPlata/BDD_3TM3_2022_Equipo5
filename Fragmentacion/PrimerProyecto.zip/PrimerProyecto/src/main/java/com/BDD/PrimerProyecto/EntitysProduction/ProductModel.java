package com.BDD.PrimerProyecto.EntitysProduction;

import javax.persistence.*;
import java.time.Instant;
import java.util.UUID;

@Entity
public class ProductModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ProductModelID", nullable = false)
    private Integer id;

    @Lob
    @Column(name = "CatalogDescription")
    private String catalogDescription;

    @Lob
    @Column(name = "Instructions")
    private String instructions;

    @Column(name = "rowguid", nullable = false)
    private UUID rowguid;
    @Column(name = "ModifiedDate", nullable = false)
    private Instant modifiedDate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCatalogDescription() {
        return catalogDescription;
    }

    public void setCatalogDescription(String catalogDescription) {
        this.catalogDescription = catalogDescription;
    }

    public String getInstructions() {
        return instructions;
    }

    public void setInstructions(String instructions) {
        this.instructions = instructions;
    }

    public UUID getRowguid() {
        return rowguid;
    }

    public void setRowguid(UUID rowguid) {
        this.rowguid = rowguid;
    }

    public Instant getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Instant modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

/*
  TODO [JPA Buddy] create field to map the 'Name' column
   Available actions: Define target Java type | Uncomment as is | Remove column mapping
  @Column(name = "Name", columnDefinition = "Name not null")
  private Object name;
*/
}